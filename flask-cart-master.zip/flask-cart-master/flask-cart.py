import os
from datetime import timedelta
from flask import Flask, request, redirect, url_for, render_template, session, flash, send_from_directory
from flask.ext.bootstrap import Bootstrap
from flask.ext.script import Manager
from flask.ext.wtf import For
from wtforms import StringField, SubmitField, HiddenField, SelectMultipleField, FileField
from wtforms.validators import Required
from flask.ext.sqlalchemy import SQLAlchemy
from werkzeug import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask.ext.mail import Mail, Message
from ftplib import FTP
from flask.ext.login import LoginManager, login_required

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

"""
Note: setting these variables through the local environment & using os.environ to access them is preferred for security reasons
"""
app.config['MAIL_SERVER'] = ""
app.config['MAIL_PORT'] = ""
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'test@test.com'
app.config['MAIL_PASSWORD'] = 'testpw' 

app.config['SQLALCHEMY_DATABASE_URI'] =\
	'sqlite:///' + os.path.join (basedir, 'data.sqlite')
#app.config['SQLALCHEMY_DATABASE_URI'] = os.environ['DATABASE_URL']
#uncomment this line if you want to use Heroku, comment instead the one before it
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

app.config['UPLOAD_FOLDER'] = './static/balls'

app.permanent_session_lifetime = timedelta(seconds=60)
app.config['SECRET_KEY'] = 'veryhard2guess'
#be more original

FTP_USER = '222'
FTP_PASS = '333'
FTP_HOST = 'ftp.ftp.com'
#again, environmental variables are preferred
manager = Manager(app)
bootstrap = Bootstrap(app)
db = SQLAlchemy(app)
mail = Mail(app)
db.drop_all()


login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(userid):
    return User.get(userid)

def populateItems():
	items = 0
	if 'items' in session:
		for x in session['items'].values():
			items += int(x)
	return items

def redirect_url(default='index'):
	return request.args.get('next') or request.referrer or url_for(default)

class User(db.Model):
	__tablename__ = 'users'
	password_hash = db.Column(db.String(120))
	id = db.Column(db.Integer, primary_key=True)
	@property 
	def password(self):
		raise AttributeError('password is not a readable attr')
	
	@password.setter
	def password(self, password):
		self.password_hash = generate_password_hash(password)

	def verify_password(self, password):
		return check_password_hash(self.password_hash, password)

class LoginForm(Form):
	user = StringField('username', validators=[Required()])
	passy = SubmitField('passw', validators=[Required()])

class EmailForm(Form):
	email = StringField('Enter your email to receive updates and special offerings', validators=[Required()])
	submit = SubmitField('Subscribe', validators=[Required()])

class ItemForm(Form):
	name = StringField('Name:', validators=[Required()])
	#price = StringField('Price:', validators=[Required()])
	category = SelectMultipleField('Category:', choices=[('accessories', 'Accessories'), ('ceramic', 'Ceramic'), ('furniture', 'Furniture'), ('jewelry', 'Jewelry'), ('lamps', 'Lamps'), ('mosaic', 'Mosaic'), ('rugs', 'Rugs'), ('leather', 'Leather'), ('rare', 'Rare')], validators=[Required()])
	image = ''
	file = FileField(validators=[Required()])
	dimensions = StringField('Dimensions:', validators=[Required()])
	price = StringField('Price', validators=[Required()])
	description = StringField('Description:', validators=[Required()])
	submit = SubmitField('Submit')

class ItemChangeImage(Form):
	file = FileField(validators=[Required()])
	submit = SubmitField('Submit')
class ItemChangeName(Form):
	name = StringField('Edit:', validators=[Required()])
	submit = SubmitField('Save')

class ItemChangeCategory(Form):
	category = SelectMultipleField('Category:', choices=[('accessories', 'Accessories'), ('ceramic', 'Ceramic'), ('furniture', 'Furniture'), ('jewelry', 'Jewelry'), ('lamps', 'Lamps'), ('mosaic', 'Mosaic'), ('rugs', 'Rugs'), ('leather', 'Leather'), ('rare', 'Rare')], validators=[Required()])
	submit = SubmitField('Save')

class ItemChangeDescription(Form):
	description = StringField('Edit2:',validators=[Required()])
	submit = SubmitField('Save')

class ItemChangePrice(Form):
	price = StringField('Edit:', validators=[Required()])
	submit = SubmitField('Save')

class ItemChangeDimensions(Form):
	dimensions = StringField('Edit:', validators=[Required()])
	submit = SubmitField('Save')

class Item(db.Model):
	__tablename__ = 'items'
	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String, unique=True)
	category = db.Column(db.String, unique=False)
	#price = db.Column(db.String)
	description = db.Column(db.String, unique=False)
	price = db.Column(db.Integer)
	dimensions = db.Column(db.String)
	image = db.Column(db.String)
	def __repr__(self):
		return '<Item %r>' % self.name

class Category(db.Model):
	__tablename__ = 'categories'
	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String(64), unique=True, index=True)

	def __repr__(self):
		return '<Categshop/rareory %r>' % self.name

db.create_all()
@app.route('/balls/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'],filename)

@app.route('/testy')
def testy():
	return render_template('testy.html')

@app.route('/contactform', methods=['GET', 'POST'])
def contactform():
	form = EmailForm()
	if form.validate_on_submit():
		msg = Message('subject', sender='newsletter@website.com', recipients=[form.email.data])
		msg.body = 'Hola'
		msg.html = '<b>NEWSLETTER</b> Hello!'
		with app.app_context():
			mail.send(msg)
		flash("Thanks for joining our mailing list")
	return render_template('contactform.html', form=form)

@app.route('/')
def index():
	items = 0
	if 'items' in session:
		for x in session['items'].values():
			print session.items()
			items += int(x)
	return render_template('new.html', items = items)

@app.route('/services')
def services():
	items = populateItems()
	return render_template('services.html', items=items)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
	form = ItemForm()
	newone = Item()
	if form.validate_on_submit():
		newone.category = form.category.data[0]
		print "!!!", form.category.data
		newone.name = form.name.data 
		newone.description = form.description.data
		newone.price = float(form.price.data)
		newone.dimensions = form.dimensions.data

		ftp = FTP(FTP_HOST)
		ftp.login(FTP_USER, FTP_PASS)
		ftp.cwd('public_html/productimages')
		#if request.method == 'POST':
		file = request.files['file']
		if file:
			filename = secure_filename(file.filename)
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			print app.config['UPLOAD_FOLDER']
			ftp.storbinary('STOR '+filename, open('./static/balls/'+filename, 'rb'))
			newone.image = filename
		db.session.add_all([newone])
		db.session.commit()
		flash('Item succesfully added !')
		return redirect('/admin')
	else:
		flash('Please make sure all info is filled out')
	return render_template('admin.html', form=form) 

@app.route('/delete/<iname>/<remove>', methods=['GET', 'POST'])
def delete(iname, remove):
	form0 = ItemChangeName()
	form2 = ItemChangeCategory()
	form3 = ItemChangeDescription()
	form4 = ItemChangePrice()
	form5 = ItemChangeDimensions()
	form6 = ItemChangeImage()
	print iname
	print remove
	cock = db.session.query(Item)
	if remove == "remove":
		ftp = FTP(FTP_HOST)
		ftp.login(FTP_USER, FTP_PASS)
		ftp.cwd('public_html/productimages')
		prev = db.session.query(Item).filter_by(name=iname).one()
		print "!!!!!!!!", prev.image, "!!!!!!!!\n"
		ftp.delete(prev.image)
		db.session.query(Item).filter_by(name=iname).delete()
		db.session.commit()
	if form0.validate_on_submit():
		print form0.name.data
		db.session.query(Item).filter_by(name=iname).update({"name": form0.name.data})
		db.session.commit()
		return redirect('/delete/a/b1')
	if form2.validate_on_submit():
		print form2.category.data
		db.session.query(Item).filter_by(name=iname).update({"category": form2.category.data[0]})
		db.session.commit()
		return redirect('/delete/a/b2')
	if form3.validate_on_submit():
		print form3.description.data
		db.session.query(Item).filter_by(name=iname).update({"description": form3.description.data})
		db.session.commit()
		return redirect('/delete/a/b3')
	if form4.validate_on_submit():
		print form4.price.data
		db.session.query(Item).filter_by(name=iname).update({"price": float(form4.price.data)})
		db.session.commit()
		return redirect('/delete/a/b4')
	if form5.validate_on_submit():
		print form5.dimensions.data
		db.session.query(Item).filter_by(name=iname).update({"dimensions": form5.dimensions.data})
		db.session.commit()
		return redirect('/delete/a/b4')
	if form6.validate_on_submit():
		ftp = FTP(FTP_HOST)
		ftp.login(FTP_USER, FTP_PASS)
		ftp.cwd('public_html/productimages')
		#if request.method == 'POST':
		file = request.files['file']
		if file:
			prev = db.session.query(Item).filter_by(name=iname).one().image
			print "!!!!!!!!", prev, "!!!!!!!!\n"
			filename = secure_filename(file.filename)
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			print app.config['UPLOAD_FOLDER']
			ftp.storbinary('STOR '+filename, open('./static/balls/'+filename, 'rb'))
			ftp.delete(prev)
		db.session.query(Item).filter_by(name=iname).update({"image": filename})
		db.session.commit()
		return redirect('/delete/a/b4')
	
	return render_template('admin_delete.html',iname=iname, cock=cock, form0=form0,form2=form2,form3=form3,form4=form4, form5=form5,form6=form6, session=session)

@app.route('/press')
def press():
	items = populateItems()
	return render_template('press.html', items=items)

@app.route('/about')
def about():
	items = populateItems()
	return render_template('about.html', items=items)

@app.route('/testy/<z>/<q>')
def test(z, q):
	if 'items' in session:
		session['items'][z] = q
	else:
		session['items'] = {}
		session['items'][z] = q
	print session['items']
	print session.items()
	return render_template('about.html')

@app.route('/shop/<cat>')
def shop(cat):
	items = populateItems()
	dog = Item.query.filter_by(category=cat).all()
	print dog
	return render_template('shop.html', item=dog, items=items)

@app.route('/addcart/<product>/<quantity>', methods=['GET', 'POST'])
def addcart(product, quantity):
	if 'items' in session:
		if product in session['items']:
			session['items'][product] += int(quantity)
			print "adding quantity to item, not a new object added to list"
		else:
			session['items'][product] = int(quantity)
			print "adding new object!!!!"
	else:
		session['items'] = {}
		session['items'][product] = int(quantity)
	return redirect(redirect_url())

@app.route('/deletecart/<product>')
def deletecart(product):
	del session['items'][product]
	return redirect(url_for('checkout'))


@app.route('/checkout')
def checkout():
	checkoutList = []
	quantityList = []
	total = 0
	if 'items' in session:
		for x in session['items']:
			y = Item.query.filter_by(name=x).first()
			if y is not None:			
				checkoutList.append(y)
				quantityList.append(session['items'][y.name])
				total += (y.price * session['items'][y.name])	
				#checkoutList[checkoutList.index(y)]['quantity'] = session['items'][x]
	else:
		print "your cart is empty!\n"
	return render_template('checkout.html', checkout=checkoutList, quant = quantityList, total=total)

@app.route('/newsletter/<email>')
def newsletter(email):
	msg = Message('subject', sender='newsletter@website.com', recipients=[email])
	msg.body = 'Hola'
	msg.html = '<b>HTML</b> body'
	with app.app_context():
		mail.send(msg)
	return redirect(redirect_url())

@app.route('/contact')
def contact():
	return render_template('contact.html')

@app.route('/signin')
def index1():
	return render_template('in.html')

@app.route('/cov')
def cov():
	return render_template('cov.html')

if __name__ == '__main__':
	manager.run()


