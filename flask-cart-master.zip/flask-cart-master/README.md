# flask-cart
Shopping cart written in Python/Flask

Beware: I am still in the process of documenting/cleaning up the code. 

Features:

-Admin page for uploading pictures, changing descriptions of items etc.

-Inventory management with POS integration

-Email newsletter management

-If your host does not support Python/Flask, you can use a free Heroku account

Todos:

-Put up templates for admin page & demo pages

-Clean up code & use application factory 

