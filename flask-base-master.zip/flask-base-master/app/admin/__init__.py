from app.admin.views import admin  # noqa
