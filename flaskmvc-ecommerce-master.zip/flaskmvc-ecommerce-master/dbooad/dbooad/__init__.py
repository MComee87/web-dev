from flask import Flask


app = Flask('dbooad')
import dbooad.views
